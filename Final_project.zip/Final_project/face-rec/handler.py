import os
import cv2
import json
from PIL import Image
from facenet_pytorch import MTCNN, InceptionResnetV1
import numpy as np
import torch
import boto3
print("Starting import statement")

# Setup environment and initialize services
os.environ['TORCH_HOME'] = '/tmp'
session = boto3.Session(
    aws_access_key_id='AKIAU6GDV3D2XRKG7UEN',
    aws_secret_access_key='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'
)
s3_client = session.client('s3')
input_bucket_name = "1228575675-stage-1"
output_bucket_name = "1228575675-output"
data_bucket_name = "1228575675-data"

# Initialize MTCNN and InceptionResnet
mtcnn = MTCNN(image_size=240, margin=0, min_face_size=20)
model_dir = '/tmp/models'
print('yeah', model_dir)
os.makedirs(model_dir, exist_ok=True)
print('yeah123', model_dir)
# resnet = InceptionResnetV1(pretrained='vggface2', model_dir=model_dir).eval()
resnet = InceptionResnetV1(pretrained='vggface2').eval()
print('resnet', resnet)

def handler(event, context):
    print("Starting face recognition handler 123", event)
    
    print(f"Type of event: {type(event)}, Event content: {event}")
    dictionary = json.loads(event)
    processed_image = dictionary['processed_images']
    print("processed_image", processed_image)
    local_image_path = f"/tmp/{processed_image}"
    print("local_image_path 123", local_image_path)
    s3_client.download_file(input_bucket_name, processed_image, local_image_path)
    
    print('downloaded')

    # Process image for face recognition
    print("Processing image:", local_image_path)
    img = Image.open(local_image_path)
    face, prob = mtcnn(img, return_prob=True)
    if face is not None:
        print(f"Face detected with probability: {prob}")
        s3_client.download_file(data_bucket_name, "data.pt", "/tmp/data.pt")
        embedding_data = torch.load('/tmp/data.pt')
        emb = resnet(face.unsqueeze(0)).detach()

        # Identify closest match
        min_distance = float('inf')
        best_name = None
        for idx, (emb_db, name) in enumerate(zip(embedding_data[0], embedding_data[1])):
            distance = torch.dist(emb, emb_db).item()
            if distance < min_distance:
                min_distance = distance
                best_name = name

        # Output result
        result_filename = os.path.splitext(processed_image)[0] + '.txt'
        result_filepath = f"/tmp/{result_filename}"
        with open(result_filepath, 'w') as file:
            file.write(best_name if best_name else "No match found")
        s3_client.upload_file(result_filepath, output_bucket_name, result_filename)
        print("Uploaded recognition result:", result_filename)
    else:
        print("No face detected.")

    return {
        'statusCode': 200,
        'body': 'Face recognition completed.'
    }