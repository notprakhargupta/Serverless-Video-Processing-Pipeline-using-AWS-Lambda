import os
import subprocess
import math
import boto3
import json

# Establish AWS session and clients
aws_session = boto3.Session(
    aws_access_key_id='AKIAU6GDV3D2XRKG7UEN',
    aws_secret_access_key='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'
)
s3_client = aws_session.client('s3')
lambda_client = aws_session.client('lambda')

source_bucket_name = "1228575675-input"
destination_bucket_name = "1228575675-stage-1"

def process_video_for_frames(video_filename):
    print("Start video splitting, filename : ",video_filename)
    filename = os.path.basename(video_filename)
    outdir = os.path.splitext(filename)[0]
    outdir = os.path.join("/tmp", outdir)
    outdir = "/tmp"
    output_dir = outdir
    print("output dir used in video function : ",output_dir)
    if not os.path.exists(outdir):
        os.makedirs(outdir)

    split_cmd = '/usr/bin/ffmpeg -ss 0 -r 1 -i ' +video_filename+ ' -vf fps=1/1 -start_number 0 -vframes 1 ' + outdir + "/" + 'test_%02d.jpg -y' 
    try:
        subprocess.check_call(split_cmd, shell=True)
    except subprocess.CalledProcessError as e:
        print(e.returncode)
        print(e.output)

    fps_cmd = 'ffmpeg -i ' + video_filename + ' 2>&1 | sed -n "s/., \\(.\\) fp.*/\\1/p"'
    fps = subprocess.check_output(fps_cmd, shell=True).decode("utf-8").rstrip("\n")
    # fps = math.ceil(float(fps))
    return outdir

def handler(event, context):
    try:
        record = event['Records'][0]['s3']
        bucket = record['bucket']['name']
        video_key = record['object']['key']
        print(f"Handling S3 event for bucket: {bucket}, key: {video_key}")

        local_video_path = f"/tmp/{os.path.basename(video_key)}"
        s3_client.download_file(bucket, video_key, local_video_path)
        print("Video downloaded successfully to local path:", local_video_path)

        frame_dir = process_video_for_frames(local_video_path)
        print("frame_dir", frame_dir)
        if frame_dir:
            print("Frame directory obtained:", frame_dir)
            for frame_file in os.listdir(frame_dir):
                if frame_file.endswith(".jpg"):
                    s3_client.upload_file(os.path.join(frame_dir, frame_file), destination_bucket_name, frame_file)
                    print(f"Uploaded {frame_file} to S3 bucket {destination_bucket_name}")
            
            payload = json.dumps({'processed_images': frame_file})
            print('before call', payload)
            # lambda_client.invoke(
            #     FunctionName='face-recognition',
            #     InvocationType='Event',
            #     Payload=payload
            # )
            
            
            
            try:
                response = lambda_client.invoke(
                    FunctionName='face-recognition',
                    InvocationType='Event',
                    Payload=json.dumps(payload)
                )
                print("Lambda invoked:", response)
            except Exception as e:
                print("Error invoking Lambda:", str(e))
                        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            print('After call', payload)
            print("Processing complete: Frames uploaded and Lambda invoked.")
        else:
            print("No frames directory found.")
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")